
import art


def display_banner():
    ascii_banner = art.text2art("Athena", font='standard')
    print(ascii_banner)
